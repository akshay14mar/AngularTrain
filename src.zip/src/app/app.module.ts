import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';

import { AppComponent } from './app.component';
import { CustomersComponent } from './customer/customers/customers.component';
import { CustomerCardComponent } from './customer/customer-card/customer-card.component';
import { CustomersListComponent } from './customer/customers-list/customers-list.component';
import { HomeComponent } from './home/home.component';
import { OrderComponent } from './orders/order/order.component';
import { Route, RouterModule } from '@angular/router';
import { LinkActivate } from './link.activate';
import { CustomerEditComponent } from './customer/customer-edit/customer-edit.component';
import {HttpClientModule}  from '@angular/common/http';
import { DataService } from 'src/common/data.service';
import { OneComponent } from './one/one.component';
import { TwoComponent } from './two/two.component';
import { ThreeComponent } from './three/three.component';
import { ReportComponent } from './orders/report/report.component';
import { HoverDirective } from './hover.directive';
const routes: Route[] = [
  {
    path: 'home',
    component: HomeComponent
  },
  {
    path: 'customers/edit/:id',
    component: CustomerEditComponent,
  },
  {
    path: 'customers',
    component: CustomersComponent,
    //canActivate:[LinkActivate]
  },
  {
    path: 'orders',
    loadChildren:()=>import('./orders/order/orders.module').then(m=>m.OrdersModule)
  },
  {
    path: '**',
    component: HomeComponent
  }
];
@NgModule({
  declarations: [
    AppComponent,

    CustomersComponent,
    CustomerCardComponent,
    CustomersListComponent,
    HomeComponent,
    OrderComponent,
    CustomerEditComponent,
    OneComponent,
    TwoComponent,
    ThreeComponent,
    HoverDirective
    
  ],
  imports: [
    RouterModule.forRoot(routes),
    FormsModule,
    HttpClientModule,
    BrowserModule
  ],
  providers: [LinkActivate,DataService],
  bootstrap: [AppComponent]
})
export class AppModule { }
