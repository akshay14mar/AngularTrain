import { Component, OnInit, Input, Output,EventEmitter } from '@angular/core';
import { Customer } from 'src/common/Customer';



@Component({
  selector: 'app-customer-card',
  templateUrl: './customer-card.component.html',
  styleUrls: ['./customer-card.component.css']
})
export class CustomerCardComponent implements OnInit {
@Input()
customers:Customer[];
@Output()
delEvent:EventEmitter<number> = new EventEmitter<number>();
  constructor() { }

  ngOnInit(): void {
  }

  deleteCustomer(id:number){
    console.log("card component " , id);
    this.delEvent.next(id);//emit the event
  }

}
